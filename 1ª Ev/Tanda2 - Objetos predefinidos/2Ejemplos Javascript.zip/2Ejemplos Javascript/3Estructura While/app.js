let i = 0;

while (i < 10) {
    console.log(`Numero: ${i}`);
    i++;
}



// Do While va a correr al menos una vez.
i = 0; // probar con 1000

do {
    console.log(`Numero: ${i}`)
    i++;
} while (i < 10);